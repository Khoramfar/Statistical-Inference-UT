import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from scipy import stats
data = pd.read_excel('Problem7Data.xls')


# Part a
plt.hist(data['mortalities'], bins=30)
plt.title('Histogram of the population values for cancer mortality')
plt.xlabel('Population Mortality')
plt.ylabel('Count')
plt.show()

# Part b
population_mean = data['population'].mean()
print('Population mean= ' , population_mean)

total_mortalities = data['mortalities'].sum()
print('total mortalities= ' , total_mortalities)

population_var = data['population'].var()
print('Population Var= ' , population_var)

population_sd = data['population'].std()
print('Population SD= ' , population_sd)

# Part c
sample_size= 25
n = 1000
sample_means=[]
for i in range(n):
    sample = data['mortalities'].sample(sample_size).mean()
    sample_means.append(sample)

plt.hist(sample_means, bins=30)
plt.title('Sampling Distribution')
plt.xlabel('Sample mean')
plt.ylabel('Count')
plt.show()

# Part d
sample_size= 25
random_sample = data.sample(sample_size)
mean_mortality = random_sample['mortalities'].mean()
total_mortality = mean_mortality * data['mortalities'].count()

print('Mortality Mean Estimation= ', mean_mortality)
print('Total Estimation= ', total_mortality)

# Part e
varub_population= random_sample['population'].var(ddof=1)
stdub_population = random_sample['population'].std(ddof=1)

print('Mortality Unbiased Variance Estimation= ', varub_population)
print('Standard Deviation Unbiased Estimation= ', stdub_population)

# Part f
Mean_CI= []

mean_population = random_sample['population'].mean()
Mean_CI.append(mean_population - 1.96 * (stdub_population/np.sqrt(25)))
Mean_CI.append(mean_population + 1.96 * (stdub_population/np.sqrt(25)))
population_mean = data['population'].mean()
print('Mean CI= ', Mean_CI[0],' , ',Mean_CI[1])
print('Population mean= ', population_mean)

Total_CI=[]

PE = mean_population * data['population'].count()
Total_CI.append(PE - 1.96 * (stdub_population*data['population'].count()/np.sqrt(25)))
Total_CI.append(PE + 1.96 * (stdub_population*data['population'].count()/np.sqrt(25)))
population_total = data['population'].count()
print('Total CI= ', Total_CI[0],' , ',Total_CI[1])
print('Population Total= ', data['population'].sum())


#Part g

#Part g->d
sample_size= 100
random_sample = data.sample(sample_size)
mean_mortality = random_sample['mortalities'].mean()
total_mortality = mean_mortality * data['mortalities'].count()

print('Mortality Mean Estimation = ', mean_mortality)
print('Total Estimation= ', total_mortality)

# Part g->e
varub_population= random_sample['population'].var(ddof=1)
stdub_population = random_sample['population'].std(ddof=1)

print('Mortality Unbiased Variance Estimation= ', varub_population)
print('Standard Deviation Unbiased Estimation= ', stdub_population)

# Part g->f
Mean_CI= []

mean_population = random_sample['population'].mean()
Mean_CI.append(mean_population - 1.96 * (stdub_population/np.sqrt(25)))
Mean_CI.append(mean_population + 1.96 * (stdub_population/np.sqrt(25)))
population_mean = data['population'].mean()
print('Mean CI= ', Mean_CI[0],' , ',Mean_CI[1])
print('Population mean= ', population_mean)

Total_CI=[]

PE = mean_population * data['population'].count()
Total_CI.append(PE - 1.96 * (stdub_population*data['population'].count()/np.sqrt(25)))
Total_CI.append(PE + 1.96 * (stdub_population*data['population'].count()/np.sqrt(25)))
population_total = data['population'].count()
print('Total CI= ', Total_CI[0],' , ',Total_CI[1])
print('Population Total= ', data['population'].sum())


# Part i
sample_size= 25
n = 1000

ratio_estimator = []
for i in range(n):
    sample = data.sample(sample_size)
    sample_mortality_mean = sample['mortalities'].mean()
    sample_population_mean = sample['population'].mean()
    ratio_estimator.append((sample_mortality_mean/sample_population_mean)*data['population'].count())


plt.hist(ratio_estimator, bins=30)
plt.title('Ratio Estimator Distribution')
plt.xlabel('Ratio')
plt.ylabel('Count')
plt.show()

#Part j
sample_size= 25
random_sample = data.sample(sample_size)
ratio_mean = (random_sample['mortalities'].mean()/random_sample['population'].mean()) * data['population'].mean()
ratio_total = ratio_mean * data['mortalities'].count()

print('Mortality Mean Estimation - Ratio= ', ratio_mean)
print('Total Estimation - Ratio = ', ratio_total)

# Part k
Mean_CI= []

Mean_CI.append(ratio_mean - 1.96 * (random_sample['population'].std()/np.sqrt(25)))
Mean_CI.append(ratio_mean + 1.96 * (random_sample['population'].std()/np.sqrt(25)))
population_mean = data['population'].mean()

Total_CI=[]

Total_CI.append(ratio_total - 1.96 * (random_sample['population'].std()/np.sqrt(25)))
Total_CI.append(ratio_total + 1.96 * (random_sample['population'].std()/np.sqrt(25)))
population_total = data['population'].count()
print('Total CI- Ratio= ', Total_CI[0],' , ',Total_CI[1])
