from scipy.stats import norm
probability = norm.cdf(-2.928)
print(probability)