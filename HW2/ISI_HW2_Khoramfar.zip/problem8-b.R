  estimate <- function(n, a, b) {
    return(sum((runif(n, min = -a, max = a) ^ 2 / a ^ 2 + runif(n, min = -b, max = b) ^ 2 / b ^ 2) < 1) / n * 4 * a * b)
  }
  
  estimate(200000, 17, 23)