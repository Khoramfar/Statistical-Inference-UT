estimate <- function(n) {
  return (4 * sum((runif(n)^2 + runif(n)^2) < 1) / n)
}

cat(estimate(10) )
cat(estimate(10000))
cat(estimate(10000000))
 
