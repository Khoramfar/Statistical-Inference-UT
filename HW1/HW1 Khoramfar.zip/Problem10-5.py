import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
data = pd.read_csv('prob10_clean.csv')

# dispersion
range = data['price'].max() - data['price'].min()
var = data['price'].var()
sd = data['price'].std()
q1 = data['price'].quantile(0.25)
q3 = data['price'].quantile(0.75)
IQR = q3 - q1

#  skewness and kurtosis
skewness = data['price'].skew()
kurtosis = data['price'].kurt()

print("Range:", range)
print("Variance:", var)
print("Standard Deviation:", sd)
print("IQR:", IQR)
print("Skewness:", skewness)
print("Kurtosis:", kurtosis)