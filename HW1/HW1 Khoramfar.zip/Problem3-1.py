import numpy as np

def Pb(n):
    trials= 10000
    count = 0
    for i in range(trials):
        birthdays = np.random.randint(1, 366, size=(n))
        if (len(birthdays) != len(np.unique(birthdays))):
            count +=1
    return count/trials

N=1
while True:
    if(Pb(N) > 0.90):
        break
    else:
        N+=1

print("smallest value of n = " , N)

