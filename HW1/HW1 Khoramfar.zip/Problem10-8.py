import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
data = pd.read_csv('prob10_clean.csv')

# Select Numerical Columns
numerical_columns = data.select_dtypes(include=np.number).columns

correlation = data[numerical_columns].corr()
plt.figure(figsize=(20, 10))
sns.heatmap(correlation, annot=True)

plt.show()