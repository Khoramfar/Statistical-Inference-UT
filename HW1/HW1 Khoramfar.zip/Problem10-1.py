import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from scipy import stats
n = 1000
# Uniform
uniform_random_numbers = np.random.uniform(0, 1, size=n)

# Normal
normal_random_numbers = np.random.normal(scale=1, size=n)

# Gamma
alpha = 2
scale = 3
gamma_random_numbers = np.random.gamma(alpha, scale, size=n)

# Exponential
rate = 1
exponential_random_numbers = np.random.exponential(rate,size=n)

# Binomial
n_b =10
p = 0.5
binomial_random_numbers = np.random.binomial(n_b,p ,size=n)

# Plots
plt.hist(uniform_random_numbers, bins=30)
plt.title("Uniform Distribution")
plt.show()

sns.kdeplot(binomial_random_numbers)
plt.title("Normal Distribution")
plt.show()

plt.hist(gamma_random_numbers, bins=100, density=True)
plt.title("Gamma Distribution")
plt.show()

sorted_numbers = np.sort(exponential_random_numbers)
plt.plot(sorted_numbers)
plt.title("Exponential Distribution")
plt.show()


sns.histplot(binomial_random_numbers, kde=True, bins=10)
plt.title("Binomial Distribution")
plt.show()

