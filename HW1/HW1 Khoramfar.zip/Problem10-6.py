import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
data = pd.read_csv('prob10_clean.csv')

engine_size = data['engine-size']
price = data['price']


plt.scatter(engine_size, price)

plt.xlabel('Engine Size ')
plt.ylabel('Price')
plt.title('Scatter Plot of Engine Size and Price')

plt.show()