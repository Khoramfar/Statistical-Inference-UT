import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
data = pd.read_csv('prob10_clean.csv')

# Select Categorical Columns
categorical_columns = ['fuel-type', 'engine-location', 'body-style']

for i in categorical_columns:
    q1 = data[i].value_counts(normalize=True).sort_values(ascending=False).iloc[0] * 100
    q3 = data[i].value_counts(normalize=True).sort_values(ascending=False).iloc[1] * 100
    IQR = q3 - q1
    lower_whisker = q1 - 1.5 * IQR
    upper_whisker = q3 + 1.5 * IQR

    data['Value'] = data.groupby(i).cumcount()
    sns.boxplot(x=i, y='Value', data=data)
    plt.xlabel(i)
    plt.ylabel('Value')
    plt.title('Boxplot of Categorical Variables')
    plt.show()