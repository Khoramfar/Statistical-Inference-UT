import numpy as np
import math
import matplotlib.pyplot as plt
def estimate(N):
    circle_points = 0

    x = np.random.uniform(0, 1, N)
    y = np.random.uniform(0, 1, N)

    r = np.sqrt(x**2 + y**2)
    circle_points = np.sum(r <= 1)

    pi = 4*circle_points / N
    return pi

N = [1000, 10000, 50000, 100000,250000,500000]
pi_estimates = []
for i in N:
  pi_estimates.append(estimate(i))

difference = []
for i in pi_estimates:
    difference.append(abs(i - math.pi))

plt.plot(N, difference)
plt.xlabel('N')
plt.ylabel('Difference between estimated and math.pi')
plt.title('Monte Carlo pi estimation')
plt.show()