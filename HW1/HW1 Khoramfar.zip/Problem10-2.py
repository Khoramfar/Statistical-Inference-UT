import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
iterations = 1000
n = 1000

# Uniform
uniform_mean = []
for i in range(iterations):
    uniform_random_numbers = np.random.uniform(0, 1, size=n)
    uniform_mean.append(np.mean(uniform_random_numbers))

# Normal
normal_mean = []
for i in range(iterations):
    normal_random_numbers = np.random.normal(scale=1, size=n)
    normal_mean.append(np.mean(normal_random_numbers))

# Gamma
alpha = 2
scale = 3
gamma_mean = []
for i in range(iterations):
    gamma_random_numbers = np.random.gamma(alpha, scale, size=n)
    gamma_mean.append(np.mean(gamma_random_numbers))

# Exponential
rate = 1
exponential_mean = []
for i in range(iterations):
    exponential_random_numbers = np.random.exponential(rate,size=n)
    exponential_mean.append(np.mean(exponential_random_numbers))

# Binomial
n_b =10
p = 0.5
binomial_mean = []
for i in range(iterations):
    binomial_random_numbers = np.random.binomial(n_b,p ,size=n)
    binomial_mean.append(np.mean(binomial_random_numbers))


sns.histplot(uniform_mean, kde=True)
plt.title("Uniform Distribution mean")
plt.show()

sns.histplot(normal_mean, kde=True)
plt.title("Normal Distribution mean")
plt.show()

sns.histplot(gamma_mean, kde=True)
plt.title("Gamma Distribution mean")
plt.show()

sns.histplot(exponential_mean, kde=True)
plt.title("Exponential Distribution mean")
plt.show()

sns.histplot(binomial_mean, kde=True)
plt.title("Binomial Distribution mean")
plt.show()