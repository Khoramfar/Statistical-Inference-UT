import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
data = pd.read_csv('prob10_clean.csv')

factors = ['engine-size', 'horsepower', 'highway-mpg']
sns.pairplot(data[factors])
plt.show()