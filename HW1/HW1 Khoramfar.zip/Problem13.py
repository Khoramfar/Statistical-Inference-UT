import numpy as np
import matplotlib.pyplot as plt
def gambler_ruin_simulate(rounds, initial_stake, bet_amount, win_probability, target_amount):
    current_stake = initial_stake
    gambler_stakes = [current_stake]
    for i in range(rounds):
        if np.random.rand() < win_probability:
            current_stake += bet_amount
        else:
            current_stake -= bet_amount

        gambler_stakes.append(current_stake)

        if current_stake <= 0:
            return gambler_stakes
        elif current_stake >= target_amount:
            return gambler_stakes

    return gambler_stakes

# Example Scenario
initial_stake = 1500
bet_amount = 200
win_probability = 0.5
target_amount = 3000
N_rounds = 100
N_simulations = 1000
N = [1000]

N_means = []
for N_simulations in N:
    gambling_result = []
    gambler_current_stake = []
    tracking = []

    for i in range(N_simulations):
        tracking = gambler_ruin_simulate(N_rounds, initial_stake, bet_amount, win_probability, target_amount)
        print(tracking)
        print("Final Stake= " + str(tracking[-1]) )
        gambling_result.append(tracking[-1])

    sum = 0
    for i in gambling_result:
        if i >= target_amount:
            sum+= 1

    probability_reach_target = sum / N_simulations
    mean = np.mean(tracking)
    N_means.append(mean)

    print("Probability of Win= " + str(probability_reach_target))
    print("Mean = " + str(mean))

    plt.plot(range(len(tracking)), tracking)
    plt.title("Gambler's Ruin Simulation")
    plt.xlabel("Round")
    plt.ylabel("Stake")
    plt.show()

print("Mean for N iterations = " + str(N_means))

plt.scatter(N, N_means)
plt.title("Gambler's Ruin Mean")
plt.xlabel("N")
plt.ylabel("Mean of Final Stake")
plt.show()