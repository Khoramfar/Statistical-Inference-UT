import numpy as np
import pandas as pd
data = pd.read_csv('prob10.csv')
pd.set_option('display.max_columns', None)

#Data cleaning

# Duplicates
data = data.drop_duplicates()

#Missing Values
data.replace("?", np.nan, inplace = True)
data.dropna(subset=["price"],axis=0,inplace=True)
data.reset_index(drop=True,inplace=True)

avg_horse_power = data["horsepower"].astype("float").mean(axis=0)
data["horsepower"].replace(np.nan,avg_horse_power,inplace=True)


#Normalize
#data['symboling'] = data['symboling']/data['symboling'].max()
data["length"] = data["length"]/data["length"].max()
data["width"] = data["width"]/data["width"].max()
data['height'] = data['height']/data['height'].max()


#Variable Types
data[["price"]] = data[["price"]].astype("float")
data[["horsepower"]] = data[["horsepower"]].astype("int")

data.head()

data.to_csv('prob10_clean.csv', index=False)
