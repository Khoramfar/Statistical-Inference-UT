import numpy as np

def Pb(n):
    trials= 10000
    count = 0
    for i in range(trials):
        birthdays = np.random.randint(1, 366, size=(n))
        unique, k = np.unique(birthdays, return_counts=True)
        if np.max(k) >= 3:
            count += 1
    return count/trials

N=1
while True:
    if(Pb(N) > 0.50):
        break
    else:
        N+=1

print("smallest value of n = " , N)

