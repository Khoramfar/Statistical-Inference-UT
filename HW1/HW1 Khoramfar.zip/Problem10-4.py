import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
data = pd.read_csv('prob10.csv')

manufacturer = data['make'].value_counts()
plt.figure(figsize=(25, 15))
plt.bar(manufacturer.index, manufacturer.values)
plt.xlabel('Manufacturer', fontsize=30)
plt.ylabel('Count', fontsize=30)
plt.title('Frequency of Car Manufacturers', fontsize=40)
plt.show()